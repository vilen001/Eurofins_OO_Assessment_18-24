﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Supreethmc_POSSystem_Q1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SaleItem item1 = new SaleItem("Monitor",7000);
            //for testing of last question
            //SaleItem item1 = new SaleItem("Monitor", 5);
            SaleItem item2 = new SaleItem("HardDisk", 5500);

            Sale sale1 = new Sale(item1, 2, 5);
            Sale sale2 = new Sale(item2, 5, 10);
            SaleList list = new SaleList("18-08-2005", "Jennifier");
            list.add(sale1);
            list.add(sale2);
            BillingSystem billingSystem = new BillingSystem();
            billingSystem.generateBill(list);
            finditemsforuser(list);
        }

        static void finditemsforuser(SaleList item)
        {
            List<Sale> sales= item.getSale();
            foreach(Sale sale in sales)
            {
                SaleItem s = sale.getItem();
                double rate = s.getRate();
                double getCurrency = convertcurrency(rate);
                if(getCurrency <= 1000)
                {
                    Console.WriteLine($"{s.getDesc()} \t {getCurrency}");
                }
            }

        }
        static double convertcurrency(double currency)
        {
            if (currency >= 0)
            {
                double ans = currency * 81;
                return ans;
            }
            return 0;
        }
    }
}
