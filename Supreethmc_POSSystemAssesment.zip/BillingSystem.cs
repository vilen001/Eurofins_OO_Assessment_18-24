﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supreethmc_POSSystem_Q1
{
    public class BillingSystem
    {
        public void generateBill(SaleList saleList)
        {
            StdTaxCalculator taxCalculator = new StdTaxCalculator();
            double tax1 = taxCalculator.getIst(ConfigurationManager.AppSettings["ISDTaxPercent"]);
            FedTaxFedral fedTax = new FedTaxFedral();
            double tax2 = fedTax.getFedTax();
            double total_amnt = 0;
            List<Sale> sales = saleList.getSale();
            foreach (Sale sale in sales)
            {
                int qty = sale.getQty();
                SaleItem s = sale.getItem();
                double rate = s.getRate();

                Console.Write($"{s.getDesc()}\t{qty}\t{rate}\t{sale.getDisc()}\n");
                double total = rate * qty;
                total_amnt += total - ((sale.getDisc() * total) / 100);
            }
            total_amnt = total_amnt + ((total_amnt * tax1) / 100) + ((total_amnt * tax2) / 100);

            Console.WriteLine($"the amount to be paid {total_amnt}");
        }
    }

    //public class StateFactory
    //{
    //    private StateFactory() { }
    //    public static StateFactory instance = new StateFactory();
    //    public StdTaxCalculator getInstance()
    //    {
    //        string className = ConfigurationManager.AppSettings["CALC"];
    //        Type theType = Type.GetType(className);
    //        return (StdTaxCalculator)Activator.CreateInstance(theType);
    //    }
    //}

    public class StdTaxCalculator
    {
        public double getIst(string state)
        {

            //string json = File.ReadAllText("C:\\Users\\Supreeth M C\\Documents\\Supreethmc_POSSystem_Q1\\Supreethmc_POSSystem_Q1\\jsconfig1.json");

            //Dictionary<string, double> taxRates = JsonConvert.DeserializeObject<Dictionary<string, double>>(json);

            //if (taxRates.ContainsKey(state.ToLower()))
            //{
            //    return taxRates[state.ToLower()];
            //}
            //else
            //{
            //    return 0;
            //}
            return 10;
        }
    }

    public class FedTaxFedral
    {
        public double getFedTax()
        {
            return double.Parse(ConfigurationManager.AppSettings["FedralTaxPercent"]);
        }
    }

}
