﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supreethmc_POSSystem_Q1
{
    public class SaleItem
    {
        double rate;
        string desc;

        public SaleItem(string desc,double rate )
        {
            this.rate = rate;
            this.desc = desc;
        }
        public string getDesc()
        {
            return desc;
        }
        public double getRate()
        {
            return rate;
        }

    }
    public class Sale
    {
        int qty;
        double disc;
        SaleItem item;
        public Sale(SaleItem item, int qty, double disc)
        {
            this.item = item;
            this.qty = qty;
            this.disc = disc;
        }
        public int getQty()
        {
            return qty;
        }
        public double getDisc()
        {
            return disc;
        }
        public SaleItem getItem()
        {
            return item;
        }
    }

    public class SaleList
    {
        string dtSale;
        string custName;
        public List<Sale> sales = new List<Sale>();
        public SaleList(string dtSale,string custName) {
            this.dtSale = dtSale;
            this.custName = custName;
        }

        public string getCustName()
        {
            return custName;
        }
        public string getdtSale()
        {
            return dtSale;
        }
        public void add(Sale sale)
        {
            sales.Add(sale);
        }
        public List<Sale> getSale()
        {
            return sales;
        }
    }
}
