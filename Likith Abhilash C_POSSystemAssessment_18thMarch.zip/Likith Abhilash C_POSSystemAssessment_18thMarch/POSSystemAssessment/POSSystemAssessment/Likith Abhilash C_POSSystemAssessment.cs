﻿//Likith Abhilash C_POSSystemAssessment

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;


namespace POSSystemAssessment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--------------------------------Point of Sale System--------------------------------");
            List<SaleItem> saleItems = new List<SaleItem>{ new SaleItem("Monitor", 7000), new SaleItem("Hard disk", 5500),
                new SaleItem("Mouse", 400),new SaleItem("Headphones", 500),new SaleItem("USB", 900)};

            Random random = new Random();
            List<Sale> sales = new List<Sale>();
            foreach (SaleItem i in saleItems)
            {
                sales.Add(new Sale(i, random.Next(1, 5), random.Next(10, 20)));//assigning the qty and discount randomly
            }
            Console.WriteLine("All items:");
            Console.WriteLine("Item Name->Item Rate");
            foreach (SaleItem i in saleItems)
            {
                Console.WriteLine($"{i.Des}->{i.Rate}");
            }
            Console.WriteLine();
            //Displays the suggested Items
            GetSuggestedItems(sales);
            SaleList list = new SaleList(DateTime.Parse("18-05-2005"), "Jennifer");

            //Here All items are getting added assuming that, the user wants all of it.
            foreach (Sale s in sales)
            {
                list.Sales.Add(s);
            }

            BillingSys billingSys = new BillingSys();
            billingSys.GenerateBill(list);

        }

        private static void GetSuggestedItems(List<Sale> sales)
        {
            Console.WriteLine("Suggested Items for you...");
            var c = (from s in sales
                     where s.Item.Rate < 1000
                     select s).ToList();
            Console.WriteLine("Item Name->Item Rate");
            foreach (Sale s in c)
            {
                Console.WriteLine($"{s.Item.Des}->{s.Item.Rate}");
            }
        }
    }
    public class SaleItem
    {
        public double Rate { get; set; }
        public string Des { get; set; }
        public SaleItem()
        {

        }
        public SaleItem(string des, double rt)
        {
            Rate = rt;
            Des = des;
        }
    }

    public class Sale
    {
        public int Qty { get; set; }
        public double Disc { get; set; }
        public SaleItem Item { get; set; }
        public Sale()
        {

        }
        public Sale(SaleItem item, int qty, double disc)
        {
            Qty = qty;
            Item = item;
            Disc = disc;
        }
    }

    public class SaleList
    {
        public DateTime DtSale { get; set; }
        public string CustName { get; set; }
        public List<Sale> Sales { get; set; } = new List<Sale>();
        public SaleList(DateTime a, string name)
        {
            DtSale = a;
            CustName = name;
        }

    }
    public class BillingSys
    {
        IStandardTaxCalculator taxCalculator = CalculatorFatory.a.GetCal();
        public void GenerateBill(SaleList list)
        {
            double b = 0;
            foreach (Sale item in list.Sales)
            {
                b =b+ item.Qty * item.Item.Rate - item.Disc;
            }
            Console.WriteLine($"Total Bill (In USD) is : USD {GetUSD(taxCalculator.calculate(b))}");
            Console.WriteLine($"Total Bill (In INr) is : INR {taxCalculator.calculate(b)}");
            
        }
        public double GetUSD(double usd)
        {
            return usd / 96;
        }
    }

    public interface IStandardTaxCalculator
    {
        double calculate(double b);
    }
    public class KATaxCalculator : IStandardTaxCalculator
    {
        public double calculate(double b)
        {
            return b + b * 0.1;
        }
    }
    public class APTaxCalculator : IStandardTaxCalculator
    {
        public double calculate(double b)
        {
            return b + b * 0.2;
        }
    }
    public class FedTaxCalculator : IStandardTaxCalculator
    {
        public double calculate(double b)
        {
            return b + b * 0.15;
        }
    }
    public class CalculatorFatory
    {
        public static readonly CalculatorFatory a = new CalculatorFatory();
        public virtual IStandardTaxCalculator GetCal()
        {
            string c = ConfigurationManager.AppSettings["GetCalculator"];//Currently using FedTaxCalculator
            Type type = Type.GetType(c);
            return (IStandardTaxCalculator)Activator.CreateInstance(type);
        }
    }
}
