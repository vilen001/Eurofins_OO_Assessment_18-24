Point of sale-.NET Programming Assessment
all classes and methods are present in program.cs