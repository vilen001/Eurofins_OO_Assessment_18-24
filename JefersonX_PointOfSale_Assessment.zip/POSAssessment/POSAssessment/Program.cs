﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSAssessment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SaleItem item1 = new SaleItem("Monitor", 7000);
            SaleItem item2 = new SaleItem("Hard disk", 5500);

            Sale sale1 = new Sale(item1, 2, 5);
            Sale sale2 = new Sale(item2, 5, 10);

            SaleList list = new SaleList(DateTime.Parse("18-08-2005"), "Jennifer");

            list.Add(sale1);
            list.Add(sale2);

            BillingSys billingSys = new BillingSys();
            billingSys.GenerateBill(list);
            Console.WriteLine();


            List<Item> items = new List<Item>
            {
                new Item { Id = 1, Rate = 500 },
                new Item { Id = 2, Rate = 750 },
                new Item { Id = 3, Rate = 1500 },
                new Item { Id = 4, Rate = 250 },
                new Item { Id = 5, Rate = 5500 },
                new Item { Id = 6, Rate = 7500 },
                new Item { Id = 7, Rate = 900 },
                new Item { Id = 8, Rate = 3200 },
                new Item { Id = 9, Rate = 1200 },
                new Item { Id = 10, Rate = 800 }
            };

            FindItemsForUser(items);
        }

        public static void FindItemsForUser(List<Item> items)
        {
            ICurrencyConverter currencyConverter = new CurrencyConverter();
            List<Item> list = items.Where(i => i.Rate < 1000).ToList();
            foreach (Item item in list)
            {
                Console.WriteLine($"Item no: {item.Id}\tRate: Dollars:{item.Rate}\tRupees:{currencyConverter.ConvertUSDtoINR(item.Rate)}");
            }
        }
    }

    public class SaleItem
    {
        public double rate;
        public string des;

        public SaleItem() { }
        public SaleItem(string desc, double rate)
        {
            this.rate = rate;
            des = desc;
        }

        public string GetDesc()
        {
            return des;
        }
        public double GetRate()
        {
            return rate;
        }

    }
    public class Sale
    {
        public int qty;
        public double disc;
        public SaleItem SaleItem { get; set; }
        public Sale() { }
        public Sale(SaleItem saleItem, int quantity, double disc)
        {
            qty = quantity;
            this.disc = disc;
            SaleItem = saleItem;
        }

        public SaleItem GetItem()
        {
            return SaleItem;
        }
        public int GetQty()
        {
            return qty;
        }
        public double GetDisc()
        {
            return disc;
        }
    }
    public class SaleList
    {
        public DateTime dtSale;
        public string custName;
        public List<Sale> saleList = new List<Sale>();

        public SaleList() { }

        public SaleList(DateTime dtSale, string custName)
        {
            this.dtSale = dtSale;
            this.custName = custName;
        }

        public string GetCustName()
        {
            return custName;
        }
        public DateTime GetDtSale()
        {
            return dtSale;
        }
        public void Add(Sale sale)
        {
            saleList.Add(sale);
        }
        public void GetSales()
        {

        }
    }

    public class BillingSys
    {
        public void GenerateBill(SaleList saleList)
        {
            StdTaxCalc stdTaxCalc = new StdTaxCalc();
            double total = 0;
            foreach (Sale sale in saleList.saleList)
            {
                double cost = sale.SaleItem.rate * sale.qty;
                double disc = sale.disc * cost / 100;
                total += cost - disc;
            }
            total += stdTaxCalc.GetIST(total, "Karnataka") + stdTaxCalc.GetFedTax(total);

            Console.WriteLine("Total bill is : " + total);
        }
    }
    public class StdTaxCalc
    {
        public double GetIST(double total, string state)
        {
            if (int.TryParse(ConfigurationManager.AppSettings["IST"], out int ist))
                return total * ist / 100;
            return total * 10 / 100;
        }
        public double GetFedTax(double total)
        {
            if (int.TryParse(ConfigurationManager.AppSettings["FED"], out int fed))
                return total * fed / 100;
            return total * 15 / 100;
        }
    }

    public class Item
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Rate { get; set; }
    }

    public interface ICurrencyConverter
    {
        double ConvertUSDtoINR(double rate);
    }
    public class CurrencyConverter : ICurrencyConverter
    {
        public double ConvertUSDtoINR(double rate)
        {
            return rate * 82.9;
        }
    }
}
