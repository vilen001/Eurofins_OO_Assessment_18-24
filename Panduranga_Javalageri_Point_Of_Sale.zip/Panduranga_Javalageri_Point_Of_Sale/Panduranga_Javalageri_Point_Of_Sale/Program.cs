﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Panduranga_Javalageri_Point_Of_Sale
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TaxCalculatoryFactory factory = TaxCalculatoryFactory.instance;
            BillingSys billingSys = new BillingSys( factory.CreateTaxCalculator());
            SaleItem item1=new SaleItem("Monitor", 7000);
            SaleItem item2 = new SaleItem("harddisk", 5500);
            Sale s1=new Sale(item1,2,5);
            Sale s2=new Sale(item2,5,10);
            SaleList l=new SaleList {dtSale= "18thaug2018",custName= "jennifer" };
            l.add(s1);
            l.add(s2);
            List<SaleList> l2=new List<SaleList>() { l };
            billingSys.generateBill(l2);


        }
    }
    public class SaleItem 
    {
        public string Desc {  get; set; }
        public double rate {  get; set; }
        public SaleItem() { }
        public SaleItem(string desc, double rate) 
        { 
            this.Desc = desc;
            this.rate = rate;
        }
        public string GetDesc() { return Desc; }
        public double GetRate() { return rate; }
    }
    public class Sale
    {
        public int qty { get; set; }
        public double disc {  get; set; }
        public SaleItem saleItem { get; set; }
        public Sale() { }
        public Sale(SaleItem item,int qty, double disc) 
        {
            this.qty = qty;
            this.disc = disc;
            this.saleItem = item;
        }
        public SaleItem GetItem() { return saleItem; }
        public double getDisc() { return disc; }
        public int getQty() { return qty; } 

    }
    public class SaleList
    {
        public List<Sale> list { get; set; } = new List<Sale>();
        public string custName { get; set; }
        public SaleList() { }
        public string getCustName() { return custName; }
        public string dtSale {  get; set; }
        public  string getDtSale() { return dtSale; }
        public void add(Sale s)
        {
            list.Add( s);
        }
        public double getSales()
        {
            return 0;
        }
    }
    public class BillingSys
    {
       
        public string state {  get; set; }
        private Istcalci Istcalci {  get; set; }
        public BillingSys(Istcalci cal)
        {
            Istcalci = cal;
        }
        public void generateBill(List<SaleList> list)
        {
            double total = 0;
            foreach (var sale in list) 
            { 
               foreach (var item in sale.list)
                {
                    double val = (item.qty * item.saleItem.rate);
                    val = val * ((100 - item.disc) / 100);
                    total += (val);
                }
            }
            double sttax = Istcalci.getFedTax();
            double tax = Istcalci.getIst();
            total = total * ((100 + sttax+tax) / 100);
            
            Console.WriteLine($"total bill is {total}");

        }
        public void findItemForuser(List<SaleItem> list)
        {
            int count = 0;
            foreach(SaleItem item in list)
            {
                count++;
                if (new america().getrupeeval(item.rate)<1000)
                {
                    Console.WriteLine(item.GetDesc());
                    Console.WriteLine(count+" "+item.GetRate());
                }
            }

        }
    }
    public interface convertor
    {
        double getrupeeval(double amy);
    }
    public class america : convertor
    {
        public  double getrupeeval(double amy)
        {
            return 82 * amy;
        }
    }

    public  interface Istcalci
    {
        double getIst();
        double getFedTax();
    }
    public class statetax2011 : Istcalci
    {
        public double getFedTax()
        {
            return (double)15;
        }

        public double getIst()
        {
            return (double)10;
        }
    }
    public class statetax2015 : Istcalci
    {
        public double getFedTax()
        {
            return (double)15;
        }

        public double getIst()
        {
            return (double)15;
        }
    }
    class TaxCalculatoryFactory
    {
        //dont allow to create an instance -private ctor
        //to inherit we need to make it private
        protected TaxCalculatoryFactory()
        {

        }
        public static readonly TaxCalculatoryFactory instance = new TaxCalculatoryFactory();

        public virtual Istcalci CreateTaxCalculator()
        {
            string ClassName = ConfigurationManager.AppSettings["CALC"];
            Type theType = Type.GetType(ClassName);
            return (Istcalci)Activator.CreateInstance(theType);
        }
    }


}
