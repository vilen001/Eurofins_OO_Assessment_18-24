﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PointOfSale
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SaleItem item1 = new SaleItem("Monitor", 7000);
            SaleItem item2 = new SaleItem("Hard Disk", 500);

            Sale sale1 = new Sale(item1, 2, 5);
            Sale sale2 = new Sale(item2, 5, 10);

            SaleList list = new SaleList("18-08-2005", "Jennifer");
            list.add(sale1);
            list.add(sale2);

            BillingSys sys = new BillingSys();
            sys.generateBill(list);

            Console.WriteLine("Finding items for users:");
            sys.FindItemsForUser(list);
        }

        
    }

    public interface ICurrencyConverter
    {
        double convert(double amount);
    }

    public class ConvertUSDtoINR : ICurrencyConverter
    {
        double INRValue = 83;
        public double convert(double amount)
        {
            return amount * INRValue;
        }
    }

    public class CurrencyConverterFactory
    {
        private CurrencyConverterFactory()
        {

        }
        public static readonly CurrencyConverterFactory Instance = new CurrencyConverterFactory();

        public ICurrencyConverter CreateCurrencyConverter()
        {
            string className = ConfigurationManager.AppSettings["CURRENCYCONVERTER"];
            Type theType = Type.GetType(className);
            return (ICurrencyConverter)Activator.CreateInstance(theType);
        }
    }

    public class SaleItem
    {
        private double rate;
        private string des;

        private SaleItem()
        {

        }

        public SaleItem(string des, double rate)
        {
            this.rate = rate;
            this.des = des;
        }

        public string GetDesc()
        {
            return des;
        }

        public double GetRate()
        {
            return rate;
        }
    }

    public class Sale
    {
        private int qty;
        private double disc;
        private SaleItem item;
        private Sale()
        {

        }

        public Sale(SaleItem _item, int _qty, double _disc)
        {
            this.item = _item;
            this.qty = _qty;
            this.disc = _disc;
        }

        public SaleItem GetItem()
        {
            return item;
        }
        public double GetDisc()
        {
            return disc;
        }

        public int GetQty()
        {
            return qty;
        }
    }

    public class SaleList
    {
        string dtSale;
        string custName;
        ArrayList Sales;

        private SaleList()
        {

        }

        public SaleList(string dtSale, string custName)
        {
            this.dtSale = dtSale;
            this.custName = custName;
            Sales = new ArrayList();
        }

        public void add(Sale sale)
        {
            Sales.Add(sale);
        }

        public string getDtSale()
        {
            return dtSale;
        }

        public string getCustName()
        {
            return custName;
        }

        public ArrayList getSales()
        {
            return Sales;
        }
    }

    public class BillingSys
    {
        private ITaxCalculator _taxCalculator;
        public BillingSys()
        {
            TaxCalculatorFactory factory = TaxCalculatorFactory.Instance;
            _taxCalculator = factory.CreateTaxCalculator();
        }
        public void generateBill(SaleList list)
        {
            double grandTotal = 0.0;

            ArrayList sales = list.getSales();

            double ist = _taxCalculator.getIST("KA");
            double fed = _taxCalculator.getFedTax();
            
            foreach(Sale sale in sales)
            {
                var item = sale.GetItem();
                double rate = item.GetRate();
                double discount = sale.GetDisc();
                int qty = sale.GetQty();
                
                // calculate tax for 1 item
                double tax = rate * ((ist + fed) / 100);

                double taxedRate = rate + tax;

                // calculate total price based on quantity
                double totalPrice = qty * taxedRate;
                double totalDiscountedPrice = totalPrice * (1 - (discount / 100));

                grandTotal += totalDiscountedPrice;
            }

            Console.WriteLine($"Grand Total {grandTotal}");
        }

        public void FindItemsForUser(SaleList list)
        {
            ArrayList sales = list.getSales();
            CurrencyConverterFactory factory = CurrencyConverterFactory.Instance;
            ICurrencyConverter converter = factory.CreateCurrencyConverter();

            foreach (Sale sale in sales)
            {
                var item = sale.GetItem();
                double rate = item.GetRate();
                if (rate < 1000)
                {
                    Console.WriteLine($"Item desc: {item.GetDesc()}");
                    Console.WriteLine($"Rate: {rate}\nRate in INR:{converter.convert(rate)}");
                }
            }
        }
    }

    public interface ITaxCalculator
    {
        double getIST(string state);
        double getFedTax();
    }

    public class StdTaxCalculator : ITaxCalculator
    {
        public double getIST(string state)
        {
            return 10;
        }

        public double getFedTax()
        {
            return 15;
        }
    }

    public class TaxCalculatorFactory
    {
        private TaxCalculatorFactory()
        {

        }
        public static readonly TaxCalculatorFactory Instance = new TaxCalculatorFactory();

        public ITaxCalculator CreateTaxCalculator()
        {
            string className = ConfigurationManager.AppSettings["CALC"];
            Type theType = Type.GetType(className);
            return (ITaxCalculator)Activator.CreateInstance(theType);
        }
    }
}
