﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sales
{
    public class Program
    {
        static void Main(string[] args)
        {
            SaleItem item1 = new SaleItem("Monitor", 7000);
            SaleItem item2 = new SaleItem("Hard Disk", 5500);
            Sale sale1 = new Sale(item1, 2, 5);
            Sale sale2 = new Sale(item2, 5, 10);

            SaleList list = new SaleList(DateTime.Parse("2005-08-18"), "Jennifer");
            list.add(sale1);
            list.add(sale2);

            /*foreach (var i in list.Sales)
            {
                Console.WriteLine(i.qty + " " + i.disc+" ");
            }*/

            BillingSys sys = new BillingSys();
            sys.generateBill(list);



            //4
            SaleItem item3 = new SaleItem("Pen Drive", 500);
            SaleItem item4 = new SaleItem("Charger", 900);
            SaleItem item5 = new SaleItem("Laptop", 55000);
            SaleItem item6 = new SaleItem("Case", 80);
            SaleItem item7 = new SaleItem("iPhone", 5500);
            SaleItem item8 = new SaleItem("Magic Pen", 400);
            List<SaleItem> items = new List<SaleItem>();
            items.Add(item1);
            items.Add(item2);
            items.Add(item3);
            items.Add(item4);
            items.Add(item5);
            items.Add(item6);
            items.Add(item7);
            items.Add(item8);
            int i = 1;
            Console.WriteLine();
            IcurrencyConverter cc = new USDtoINR();
            foreach (SaleItem item in items)
            {

                if (item.rate < 1000)
                {
                    Console.WriteLine($"Item No {i}  Item Rate {item.rate}$  USD TO INR  {cc.convert(item.rate)} Rs");
                }
                i++;
            }





        }
    }

    public class SaleItem
    {
        public double rate { get; set; }
        public string des { get; set; }

        public SaleItem(string des, double rate)
        {
            this.rate = rate;
            this.des = des;
        }

    }
    public class Sale
    {
        public int qty { get; set; }
        public double disc { get; set; }
        public SaleItem item = null;
        public Sale(SaleItem item, int qty, double disc)
        {
            this.qty = qty;
            this.disc = disc;
            this.item = item;
        }
    }
    public class SaleList
    {
        public DateTime dtSale { get; set; }
        public string custName { get; set; }
        public List<Sale> Sales { get; set; } = new List<Sale>();
        public SaleList(DateTime dtSale, string custName)
        {

            this.custName = custName;
            this.dtSale = dtSale;
        }
        public void add(Sale s)
        {
            Sales.Add(s);
        }

    }
    public class BillingSys
    {

        public void generateBill(SaleList saleList)
        {
            double grandTotal = 0;
            foreach (var product in saleList.Sales)
            {
                double rate = product.item.rate;
                double totalCost = product.qty * rate;
                double discountedPrice = totalCost * (1 - ((product.disc) / 100));
                grandTotal += discountedPrice;

            }
            Console.WriteLine("Without Tax");
            Console.WriteLine(grandTotal);
            Console.WriteLine("With Tax");
            StdTaxCalc stc = new StdTaxCalc();
            // double STax = stc.totalTax("KA");

            //  or from App Config extract state

            string stateName = ConfigurationManager.AppSettings["State"];
            double STax = stc.totalTax(stateName);

            double TotalWithTax = grandTotal * (1 + ((STax) / 100));
            //return grandTotal;
            Console.WriteLine(TotalWithTax);
        }
    }
    public class StdTaxCalc
    {

        public double totalTax(string state)
        {
            double FinalTax = 0;
            Tax ist = new IST();
            FinalTax += ist.getTax("state");

            Tax fedTax = new FedTax();
            FinalTax += fedTax.getTax("state");
            return FinalTax;
        }

    }
    // or Interface 
    public abstract class Tax
    {
        public abstract double getTax(string State);
    }
    // Child Class
    public class IST : Tax
    {
        public override double getTax(string state)
        {
            int value = int.Parse(ConfigurationManager.AppSettings["ISTtax"]);
            // return 10
            // or
            return value;
        }
    }
    public class FedTax : Tax
    {
        public override double getTax(string state)
        {
            //return 15;
            // or
            int value = int.Parse(ConfigurationManager.AppSettings["FEDtax"]);
            return value;
        }
    }

    public interface IcurrencyConverter
    {
        double convert(double value);
    }
    public class USDtoINR : IcurrencyConverter
    {
        public double convert(double value)
        {
            return value * 80;
        }
    }
}
