The app config dynamicalls fetches the state name
and the tax values
