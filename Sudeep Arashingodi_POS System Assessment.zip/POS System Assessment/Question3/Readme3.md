﻿## Iam calculating the bill in the main function.

This project has 5 classes
* SaleItem
* Sale
* SaleList
* BillingSys
* StdTaxCalc


 I have implemented all the required methodes and fields. 
 
 I have used **C# properties** for the class fields.

 ### In class BillingSys
 *  BillingSys has StdTaxCalc. And to calculate the **IST (Inter state tax)** , we need a state name, iam getting it from the config file.( State can be changed directly from config file without chaning the code).
* Also in the methods **getIST** and **getFedTax**, iam using config file to get the tax rates. (So if the tax rates vary, then we can change in the config file without changeing our actual code ).

