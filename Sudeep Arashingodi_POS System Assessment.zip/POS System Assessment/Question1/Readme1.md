﻿This project has 3 classes
* SaleItem
* Sale
* SaleList

 I have implemented all the required methodes and fields. 
 
 I have used **C# properties** for the class fields.