﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }

    public class SaleItem
    {
        public double rate { get; set; }
        public string des { get; set; }


        public SaleItem()
        {

        }

        public SaleItem(string des, double rt)
        {
            this.des = des;
            this.rate = rt;
        }



    }

    public class Sale
    {
        public int qty { get; set; }
        public double disc { get; set; }

        public SaleItem saleItem { get; set; } = new SaleItem();

        public Sale() { }

        public Sale(SaleItem _item, int _qty, double _disc)
        {
            this.qty = _qty;
            this.disc = _disc;
            this.saleItem = _item;
        }
    }

    public class SaleList
    {
        public DateTime dtSale { get; set; }

        public string cusName { get; set; }

        public List<Sale> Sales { get; set; } = new List<Sale>();

        public SaleList() { }

        public SaleList(string _dtSale, string _cusName)
        {
            DateTime dateTime;
            DateTime.TryParse(_dtSale, out dateTime);

            this.dtSale = dateTime;
            this.cusName = _cusName;
        }

        public void add(Sale sale)
        {
            this.Sales.Add(sale);
        }


    }


}
