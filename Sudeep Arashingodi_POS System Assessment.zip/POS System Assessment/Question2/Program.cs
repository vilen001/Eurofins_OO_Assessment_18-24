﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
  
        internal class Program
        {
            static void Main(string[] args)
            {
             }
    }

    public class SaleItem
    {
        public double rate { get; set; }
        public string des { get; set; }


        public SaleItem()
        {

        }

        public SaleItem(string des, double rt)
        {
            this.des = des;
            this.rate = rt;
        }



    }

    public class Sale
    {
        public int qty { get; set; }
        public double disc { get; set; }

        public SaleItem saleItem { get; set; } = new SaleItem();

        public Sale() { }

        public Sale(SaleItem _item, int _qty, double _disc)
        {
            this.qty = _qty;
            this.disc = _disc;
            this.saleItem = _item;
        }
    }

    public class SaleList
    {
        public DateTime dtSale { get; set; }

        public string cusName { get; set; }

        public List<Sale> Sales { get; set; } = new List<Sale>();

        public SaleList() { }

        public SaleList(string _dtSale, string _cusName)
        {
            DateTime dateTime;
            DateTime.TryParse(_dtSale, out dateTime);

            this.dtSale = dateTime;
            this.cusName = _cusName;
        }

        public void add(Sale sale)
        {
            this.Sales.Add(sale);
        }


    }


    public class BillingSys
    {
        public StdTaxCalc stdTaxCalc { get; set; } = new StdTaxCalc();
        public void generateBill(SaleList list)
        {
            double totalBeforeTax = 0;
            foreach (Sale sale in list.Sales)
            {
                double totalPrice = (sale.qty * sale.saleItem.rate);
                double totalPriceAfterDiscount = totalPrice * ((100 - sale.disc) / 100);
                totalBeforeTax += totalPriceAfterDiscount;

            }

            //getting state name from config file
            string StateName = ConfigurationManager.AppSettings["StateName"];

            double totalTaxPercentage = stdTaxCalc.getFedTax() + stdTaxCalc.getIST(StateName);
            double totalAfterTax = totalBeforeTax * ((100 - totalTaxPercentage) / 100);

            Console.WriteLine("Your Total Befor Tax: " + totalBeforeTax);
            Console.WriteLine("Your Total After Tax: " + totalAfterTax);
        }
    }

    public class StdTaxCalc
    {
        public double getIST(String state)
        {
            double d = double.Parse("10.88");

            //reading the ISt tax value from the config file, using state name

            string taxstring = ConfigurationManager.AppSettings[state];
            double Statetax = 0;

            double.TryParse(taxstring, out Statetax);


            return Statetax;
        }

        public double getFedTax()
        {
            //reading the FED tax value from the config file

            string taxstring = ConfigurationManager.AppSettings["FedTax"];
            double Fedtax = 0;

            double.TryParse(taxstring, out Fedtax);


            return Fedtax;
        }
    }
}



