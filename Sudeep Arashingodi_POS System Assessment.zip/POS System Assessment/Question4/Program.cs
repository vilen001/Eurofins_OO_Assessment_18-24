﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //get the repository from the factory
            Irepo repository = IrepoFactory.Instance.GetRepo();

            // get all items from the repository from this  commented code
            //             
            //List<Item> items = repository.getAllItems();

            //here iam using sample data, but in actual the items come from the repository
            List<Item> items = new List<Item>() 
            { 
             new Item(){ItemNo=1,Rate=200},
             new Item(){ItemNo=2,Rate=2500},
             new Item(){ItemNo=3,Rate=900},
             new Item(){ItemNo=4,Rate=1800},
             new Item(){ItemNo=5,Rate=5000}

            };


            //taking a currencyConverter of type USDtoINR with conversionRate as 84
            CurrencyConverter currencyConverter = new USDtoINR(84);


            //traverse the list and find the items less than 1000 
            Console.WriteLine("List of Items whose rate is less than $1000 are;\n ");
            Console.WriteLine("Item No.\tRate");
            foreach (Item item in items)
            {
                if (item.Rate < 1000)
                {
                    Console.WriteLine($"{item.ItemNo}\t\t{currencyConverter.convert(item.Rate)}");

                }
            }



        }
    }

    public class IrepoFactory
    {
        public static readonly IrepoFactory Instance = new IrepoFactory();

        protected IrepoFactory() { }

        public Irepo GetRepo()
        {
            string className = (ConfigurationManager.AppSettings["repo"]);
            //reflextion 

            Type thetype = Type.GetType(className);
            return (Irepo)Activator.CreateInstance(thetype);

        }
    }

    public interface Irepo
    {
        List<Item> getAllItems();
    }

    public class FileRepo : Irepo
    {
        public List<Item> getAllItems()
        {
           List<Item> items= new List<Item>();

            try
            {
                // read from file and return the items
                using (StreamReader reader = new StreamReader("Info.txt"))
                {
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        string[] parts = line.Split(new char[] { ' ' });

                        Item item = new Item()
                        {
                            ItemNo = int.Parse(parts[0]),
                            Rate = int.Parse(parts[1]),
                        };
                    }
                }
            }
            catch(Exception e)
            {
                //iam printting on screen, u can log to error log file
                Console.WriteLine("Error while Reading the Repo");
            }

            return items;   
        }
    }

    public interface CurrencyConverter
    {
        double convert(double rate);
    }

    public class USDtoINR : CurrencyConverter
    {
        private double conrsionRate;

        public USDtoINR(double conrsionRate)
        {
            this.conrsionRate = conrsionRate;
        }

        public double convert(double rate)
        {
            return rate* conrsionRate;
        }
    }

    public class Item
    {
        public int ItemNo { get; set; }
        public double Rate { get; set; }

    }
}
