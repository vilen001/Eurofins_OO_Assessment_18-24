﻿* ### Here i have written the logic to get the Items whose Rates less then 1000USD, then iam converting the Rate to INR using a CurrencyConverter

* ### I have made factory to choose the Repository,  and here i have used FileRepo(but here i have given the sample data by myself)