﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointOfSale.ConsoleApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            SaleItem item1 = new SaleItem("Monitor", 7000);
            SaleItem item2 = new SaleItem("Hard disk", 5500);

            Sale sale1 = new Sale(item1, 2, 5);
            Sale sale2 = new Sale(item2, 5, 10);

            SaleList list = new SaleList("18-08-2005", "Jennifer");
            list.add(sale1);
            list.add(sale2);

            BillingSys sys = new BillingSys();
            sys.GenerateBill(list);

            //to show FindItemsForUser():
            SaleItem item3 = new SaleItem("Phone case", 800);
            SaleItem item4 = new SaleItem("Screen Cover", 500);

            List<SaleItem> itemList = new List<SaleItem>();
            itemList.Add(item1);
            itemList.Add(item2);    
            itemList.Add(item3);
            itemList.Add(item4);

            FindItemsForUser(itemList);

        }
        public static void FindItemsForUser(List<SaleItem> items)
        {
            bool flag = false;
            Console.WriteLine("\nItems under 1000:");
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].Rate < 1000)
                {
                    flag = true;
                    Console.WriteLine($"Item{i + 1} - {items[i].Des} - {items[i].Rate}INR - {Math.Round(items[i].Rate / CurrencyConverter.USDtoINR(), 2)}USD");
                }
            }
            if(flag == false)
                Console.WriteLine("There were no items under 1000");
        }
    }
    public class SaleItem
    {
        public double Rate { get; set; }
        public string Des { get; set; }
        public SaleItem(string des, double rt)
        {
            Rate = rt;
            Des = des;
        }
    }
    public class Sale
    {
        public int Qty { get; set; }    
        public double Disc { get; set; }    
        public SaleItem SaleItem { get; set; }  
        public Sale(SaleItem saleItem, int qty, double disc) 
        {
            SaleItem = saleItem;   
            Qty = qty;
            Disc = disc;    
        }
    }
    public class SaleList
    {
        public string DtSale { get; set; }
        public string CustName { get; set; }
        public List<Sale> Sales { get; set; } = new List<Sale>();
        public SaleList(string dt, string custName)
        {
            DtSale = dt;
            CustName = custName;    
        }
        public void add(Sale sale)
        {
            Sales.Add(sale);
        }
        public List<Sale> GetSales()
        {
            return Sales;
        }
    }
    public class BillingSys
    {
        StdTaxCalc taxCalc = new StdTaxCalc(); 
        public void GenerateBill(SaleList saleList)
        {
            double total = 0;
            foreach(var sale in saleList.Sales)
            {
                total += (sale.Qty * sale.SaleItem.Rate) - (sale.Qty * sale.SaleItem.Rate)*(sale.Disc/100);
            }
            Console.WriteLine($"Total = {total}");
            Console.WriteLine($"Total with state tax = {total - total*(taxCalc.GetIST("KA")/100)}");
            Console.WriteLine($"Total with fed tax = {total - total * (taxCalc.GetFedTax() / 100)}");
        }
    }
    public class StdTaxCalc
    {
        public double GetIST(string state)
        {
            //values revised frequently stored in App.config file!
            return Convert.ToDouble(ConfigurationManager.AppSettings["IST"]);
        }
        public double GetFedTax()
        {
            return Convert.ToDouble(ConfigurationManager.AppSettings["Fed"]);
        }
    }
    public class CurrencyConverter
    {
        public static double USDtoINR()
        {
            return Convert.ToDouble(ConfigurationManager.AppSettings["USD"]);
        }
    }
}
