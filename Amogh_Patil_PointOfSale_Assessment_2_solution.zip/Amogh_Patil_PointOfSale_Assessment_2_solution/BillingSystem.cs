﻿using System;
using System.Collections.Generic;

namespace Point_Of_Sale_Assessment_1
{
    public class BillingSystem
    {
        //List<SaleList> salelists
        StdTaxCalc taxCalc = new StdTaxCalc();
        public void GenerateBill( SaleList list)
        {
            double bill = 0;
            foreach(Sale s in list.Sales)
            {
                var price =  s.Qty * s.saleitem.Rate;
                price = price - (price * s.Disc / 100);
                bill += price;

                bill = bill + (bill * taxCalc.GetIstTax("IST") / 100) + (bill * taxCalc.GetFedTax() / 100);
            }
            
            Console.WriteLine($"bill for {list.CustomerName} = {bill}");

        }
        public void FindItemsForUser(List<SaleItem> items)
        {
            Console.WriteLine("you may be attracted to buy few more items below 1000 like ... ");
            USD_To_INR ctr = new USD_To_INR();
            int item_no = 0;
            foreach(SaleItem item in items)
            {
                if(item.Rate < 1000)
                {
                    Console.WriteLine(item_no+1 +"). "+$"{item.Des}  cost in Rs = "+ctr.Convert(item.GetRate()));
                    item_no++;
                }
                
            }
        }
    }

}
