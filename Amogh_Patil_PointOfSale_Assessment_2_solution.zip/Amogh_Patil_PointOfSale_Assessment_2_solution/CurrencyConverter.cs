﻿namespace Point_Of_Sale_Assessment_1
{
    public interface CurrencyConverter
    {
        double Convert(double money);
    }

}
