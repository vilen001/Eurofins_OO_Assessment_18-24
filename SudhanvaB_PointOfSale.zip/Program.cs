﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sudhanva_PointOfSale
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SaleItem item1 = new SaleItem("Monitor",7000);
            SaleItem item2 = new SaleItem("Hard Disc",5500);

            Sale sale1 = new Sale(item1,2,5);
            Sale sale2 = new Sale(item2,5,10);

            SaleList list = new SaleList("18-08-2005","Jennifer");
            list.Add(sale1);
            list.Add(sale2);

            BillingSys sys = new BillingSys();
            sys.GenerateBill(list);
            Console.WriteLine("================================\n\n\n\n");

            // creating a list of items as it was not provided
            List<SaleItem> list2 = new List<SaleItem>()
            {
                new SaleItem("Monitor",700),
                new SaleItem("Paper",7),
                new SaleItem("Laptop",7000),
                new SaleItem("Keyboard",400),
                new SaleItem("Mouse",65),
                new SaleItem("Table",1700),
                new SaleItem("Hard Disc",5500)
            };
            sys.FindItemsForUser(list2);

        }
    }
    public class SaleList
    {
        public string DtSale { get; set; }
        public string CustName { get; set; }
        public List<Sale> sales { get; set; } = new List<Sale>();
        public SaleList(string date,string name)
        {
            DtSale = date;
            CustName = name;
        }
        public void Add(Sale sale)
        {
            sales.Add(sale);
        }
        public List <Sale> GetSales()
        {
            return sales;
        }
    }

    public class Sale
    {
        public int Qty { get; set; }
        public double Disc { get; set; }
        public SaleItem SaleItem { get; set; }
        public Sale(SaleItem _saleitem,int _qty,double _disc)
        {
            Qty = _qty;
            Disc = _disc;
            SaleItem = _saleitem;
        }
    }
    public class SaleItem
    {
        public double Rate { get; set; }
        public string Des { get; set; }
        public SaleItem(string des,double rt) {
            Rate = rt; Des = des;
        }
    }
    public class BillingSys
    {

        public void GenerateBill(SaleList salelist)
        {
            Console.WriteLine($"Name : {salelist.CustName}\nDate : {salelist.DtSale}\n\n=======================================\n");
            Console.WriteLine("Item\t\tQuantity\tRate\tDiscount\tPrice After Discount\tIST Tax\tFederal Tax\tPrice After Tax");
            double total = 0;
            foreach (Sale sale in salelist.sales)
            {
                double totalPrice = sale.Qty * sale.SaleItem.Rate;
                double discount = totalPrice * (sale.Disc / 100);
                double finalPrice = totalPrice - discount;

                // get total tax
                double ISTTax = finalPrice * (StdTaxCalc.GetIST("Karnataka") / 100);
                double FedTax = finalPrice * (StdTaxCalc.GetFedTax() / 100);
                double totalTax = ISTTax + FedTax;
                double priceAfterTax = totalPrice + ISTTax + FedTax;
                total += priceAfterTax;
                Console.WriteLine($"{sale.SaleItem.Des}\t\t{sale.Qty}\t{sale.SaleItem.Rate}\t{sale.Disc}\t{finalPrice}\t{ISTTax}\t{FedTax}\t{priceAfterTax}");
            }
            Console.WriteLine("Final amount to be paid by the customer: " + total);
        }
        public void FindItemsForUser(List<SaleItem> items)
        {
            Console.WriteLine("Items under 1000 dollars:");
            Console.WriteLine("Item\tRate(in USD)\tRate(in INR)");
            foreach (SaleItem item in items)
            {
                if(item.Rate < 1000)
                {
                    ICurrencyConverter currencyConverter = new USDtoINRConverter();
                    double inr = currencyConverter.Convert(item.Rate);
                    Console.WriteLine($"{item.Des}\t{item.Rate}\t{inr}");
                }
            }
        }
    }
    public class StdTaxCalc
    {
        public static double IST { get; set; } = 10;
        public static double FedTax { get; set; } = 15;
        public static double GetIST(string state)
        {
            return IST;
        }
        public static double GetFedTax()
        {
            return FedTax;
        }
    }
    public interface ICurrencyConverter
    {
        double Convert(double rate);
    }
    public class USDtoINRConverter : ICurrencyConverter
    {
        public double Convert(double rate)
        {
            // 1 USD = 82.9 INR as of now

            return rate * 82.9;
        }
    }


}
