- I have taken a custom dataset of items for question 4 as it was not provided
- I have taken the current price of INR 

Steps for execution:
1. Create a new concole project (.NET Framework) on Visual Studio 2024
2. Transfer (copy and paste) Program.cs and ClassDiagram1.cd files from the zip file to the new project
3. Run the Program.cs file to get the output

Output:
Name : Jennifer
Date : 18-08-2005

=======================================

Item            Quantity        Rate    Discount        Price After Discount    IST Tax Federal Tax     Price After Tax
Monitor         2       	7000    5       	13300   		1330    1995    	17325
Hard Disc       5       	5500    10      	24750   		2475    3712.5  	33687.5
Final amount to be paid by the customer: 51012.5
================================




Items under 1000 dollars:
Item    	Rate(in USD)    Rate(in INR)
Monitor 	700     	58030
Paper   	7       	580.3
Keyboard        400     	33160
Mouse   	65      	5388.5
Press any key to continue . . .