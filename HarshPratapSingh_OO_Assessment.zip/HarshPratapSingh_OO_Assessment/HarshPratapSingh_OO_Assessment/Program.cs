﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HarshPratapSingh_OO_Assessment
{
    public class Program
    {
        static void Main(string[] args)
        {
            //discount in % ex : disc = 15 => 15 % discount
            // Given test input 
            Console.WriteLine("TestInput");
            SaleItem item1 = new SaleItem("Monitor", 7000);
            SaleItem item2 = new SaleItem("HardDisk", 5500);
            Sale sale1 = new Sale(item1, 2, 5);
            Sale sale2 = new Sale(item2, 5, 10);
            SaleList List = new SaleList("18-08-2005", "Jeniffer");
            List.saleList.Add(sale1);
            List.saleList.Add(sale2);
            BillingSystem sys = new BillingSystem();
            sys.generateBill(List);
            findItemsforUser(List.saleList);
            Console.WriteLine("--------------");


            // input to test finditemsforuser
            SaleItem saleItem = new SaleItem
            {
                rate = 10,
                des = "mango"
            };

            SaleItem saleItem2 = new SaleItem
            {
                rate = 30,
                des = "banana"
            };
            Sale sale = new Sale
            {
                qty = 1,
                disc = 15,
                saleItem = saleItem
            };
            Sale sale22 = new Sale
            {
                qty = 2,
                disc = 10,
                saleItem = saleItem2
            };
            SaleList saleList = new SaleList
            {
                dtSale = "18-10-2022",
                custName = "Harsh"
            };
            saleList.saleList.Add(sale);
            saleList.saleList.Add(sale22);
            BillingSystem billingSystem = new BillingSystem();
            billingSystem.generateBill(saleList);
            findItemsforUser(saleList.saleList);


        }
        public static void findItemsforUser(List<Sale> item)
        {
            CurrencyConverter currencyConverter = new UsdToInr();
            Console.WriteLine("The items that have rate less than 1000 usd are : ");
            foreach (var e in item)
            {
                if (e.saleItem.rate <= 1000)
                {
                    Console.WriteLine($"Name : {e.saleItem.des} \t Rate : {currencyConverter.converter(e.saleItem.rate)} inr ({e.saleItem.rate} usd) ");
                }
            }
        }
    }
    public interface CurrencyConverter
    {
        double converter(double amount);
    }
    public class UsdToInr : CurrencyConverter
    {
        public double converter(double amount)
        {
            return amount * 80;
        }
    }
    public class SaleItem
    {
        public double rate { get; set; }
        public string des { get; set; }
        public SaleItem()
        {

        }
        public SaleItem(string des, double rate)
        {
            this.rate = rate;
            this.des = des;
        }
    }
    public class Sale
    {
        public int qty { get; set; }
        public double disc { get; set; }
        public SaleItem saleItem { get; set; } = new SaleItem();
        public Sale()
        {

        }
        public Sale(SaleItem item, int qty, double disc)
        {
            this.saleItem = item;
            this.qty = qty;
            this.disc = disc;
        }
    }
    public class SaleList
    {
        public string dtSale { get; set; }
        public string custName { get; set; }
        public List<Sale> saleList { get; set; } = new List<Sale>();
        public SaleList()
        {

        }
        public SaleList(string dateTime, string custname)
        {
            dtSale = dateTime;
            custName = custname;
        }
    }
    public class BillingSystem
    {
        private StdTaxCalculator taxCalculator = new StdTaxCalculator();
        string state = ConfigurationManager.AppSettings["state"];
        public void generateBill(SaleList saleList)
        {
            double amount = 0;
            foreach (var sale in saleList.saleList)
            {
                amount +=  sale.saleItem.rate * sale.qty * (100 - sale.disc) / 100;
            }
            var InterstateTax = taxCalculator.getIst(state.ToLower());
            var FederalTax = taxCalculator.getFedTax();

            var total = amount + ((InterstateTax + FederalTax) * amount);
            Console.WriteLine("total amount : " + amount);
            Console.WriteLine("total tax : " + (InterstateTax + FederalTax) * amount );
            Console.WriteLine("Total after taxes : " + total);

        }

    }
    public class StdTaxCalculator
    {
        public double getIst(string state) // gets the value of the tax from the app.config accoring to the state
        {
            return double.Parse(ConfigurationManager.AppSettings[state]);
        }
        public double getFedTax()
        {
            return double.Parse(ConfigurationManager.AppSettings["fedTax"]);
        }
    }
}
   
    

