The genratebill is used to generate the final amounts
the state parameter is retrieved from a config file 
the same way based on the name of the state the tax is again retrievd from the config file