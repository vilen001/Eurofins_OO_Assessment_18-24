﻿This solution is for the Point of Sale system assessment
	=> All the classes used in the solution are present in the "Program.cs" file.
	=> In the main method the code for Q3 and Q4 are executed.
	=> For the other questions for the structure of the program, the classes are in the file containing the required methods, attributes and properties.
	


	- Shashank Joshi