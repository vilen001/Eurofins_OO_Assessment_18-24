﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointOfSaleSystem
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Q3 implementation of the given code
            Console.WriteLine("============================================== Q3 =====================================================");
            Console.WriteLine();
            SaleItem Item1 = new SaleItem("Monitor", 7000);
            SaleItem Item2 = new SaleItem("Hard disk", 5500);

            Sale sale1 = new Sale(Item1, 2, 5);
            Sale sale2 = new Sale(Item2, 5, 10);
            

            SaleList list = new SaleList(DateTime.Parse("18-08-2005"), "Jennifer");
            list.add(sale1);
            list.add(sale2);

            BillingSys sys = new BillingSys();
            sys.generateBill(list);
            Console.WriteLine();
            Console.WriteLine("============================================== Q3 =====================================================");

            //Q4 - as there was no list provided, I have assumed a list of saleitems used that in consideration with the constrants given as the list being passed to the method
            Console.WriteLine("============================================== Q4 =====================================================");
            List<SaleItem> Items = new List<SaleItem>();
            SaleItem i1 = new SaleItem("Phone 1", 200);
            SaleItem i2 = new SaleItem("Laptop 1", 1200);
            SaleItem i3 = new SaleItem("Phone 2", 700);
            SaleItem i4 = new SaleItem("Phone 3", 800);
            SaleItem i5 = new SaleItem("Laptop 5", 900);
            SaleItem i6 = new SaleItem("Tablet 1", 600);
            SaleItem i7 = new SaleItem("Watch 1", 50);
            SaleItem i8 = new SaleItem("Watch 3", 800);
            SaleItem i9 = new SaleItem("Phone 6", 300);
            Items.Add(i1);
            Items.Add(i2);
            Items.Add(i3);
            Items.Add(i4);
            Items.Add(i5);
            Items.Add(i6);
            Items.Add(i7);
            Items.Add(i8);
            Items.Add(i9);
            findItemsForUser(Items);

            Console.WriteLine("============================================== Q4 =====================================================");

        }
        public static void findItemsForUser(List <SaleItem> List)
        {
            ICurrencyConverter conv = new DollarToRuppeeConverter();
            double temprt;
            foreach (SaleItem Item in List) 
            {
                temprt = conv.convertCurrency(Item.rate);
                if(temprt < conv.convertCurrency(1000))
                {
                    Console.WriteLine($"{Item.des}  ---  {temprt}");
                }
            }
        }
    }
    public interface ICurrencyConverter
    {
        double convertCurrency(double c1);
    }
    public class DollarToRuppeeConverter : ICurrencyConverter
    {
        public double convertCurrency(double c1)
        {
            return  c1 * 82.91;
        }
    } 
    public class SaleItem
    {
        public double rate { get; set; }
        public string des { get; set; }


        public SaleItem()
        {
            this.rate = 0;
            this.des = null;
        }
        public SaleItem(string des, double rt)
        {
            this.des = des;
            this.rate = rt;
        }
        public string GetDesc()
        {
            return this.des;
        }
        public double GetRate()
        {
            return this.rate;
        }

    }
    public class Sale
    {
        public SaleItem item { get; set; }
        public int qty { get; set; }
        public double disc { get; set; }

        public Sale()
        {
            this.qty = 0;
            this.disc = 0;
        }
        public Sale(SaleItem _Item, int _qty, double _disc)
        {
            this.qty = _qty;
            this.disc = _disc;
            this.item = _Item;
        }
        public double GetDiscount()
        {
            return this.disc;
        }
        public int GetQty()
        {
            return this.qty;
        }
    }
    public class SaleList
    {
        public List<Sale> SalesList = new List<Sale>();
        public DateTime dtSale { get; set; }
        public string custName { get; set; }


        public SaleList()
        {

        }
        public SaleList(DateTime dtSale, string custName)
        {
            this.dtSale = dtSale;
            this.custName = custName;
        }

        public DateTime getSaleDate()
        {
            return this.dtSale;
        }
        public string getCusName()
        {
            return this.custName;
        }
        public void add(Sale s)
        {
            SalesList.Add(s);
        }
        public List<Sale> getSales()
        {
            return this.SalesList;
        }


    }
    public class BillingSys
    {
        double TotalBill = 0;
        double temp = 0;
        
        double IST = StdTaxCalc.getIST("");
        double FED = StdTaxCalc.getFedTax();
        public void generateBill(SaleList SalesList)
        {
            foreach (var Sale in SalesList.SalesList)
            {
                temp = Sale.qty *(Sale.item.rate - (Sale.item.rate * (Sale.disc / 100)));
                TotalBill = temp + (Sale.qty*(IST * temp)) +(Sale.qty*(FED * temp));
                temp = 0;
            }
            Console.WriteLine($"The total bill inclusive of all tax is {TotalBill}");

        }
    }

    public static class StdTaxCalc
    {
        public static double getIST(string state)
        {
            return (double) 10/100;
        }
        public static double getFedTax()
        {
            return (double) 15/100;
        }
    }
}
