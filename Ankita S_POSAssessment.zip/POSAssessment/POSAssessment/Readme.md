﻿Point of sale - .Net Programming

This project has Two Parts:
1. Generate Bill
2. Find Item for User Based on Rate

Generate Bill : generateBill() method of BillingSys finds the Grand Total after applying the tax, for calculating the tax, using app config the tax is made configurable. It also uses the Sale, SaleList, SaleItem classes.

FindingItem : FindItemsForUser(List<Item> items) method is used to find the items whose rate is less than 1000.