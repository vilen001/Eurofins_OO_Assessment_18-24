﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace POSAssessment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SaleItem item1 = new SaleItem("Monitor", 7000);
            SaleItem item2 = new SaleItem("HardDisk",5500);

            Sale sale1 = new Sale(item1,2,5);
            Sale sale2 = new Sale(item2, 5, 10);

            SaleList list = new SaleList("18-08-2005","Jennifer");
            list.add(sale1);
            list.add(sale2);

            BillingSys sys = new BillingSys();
            sys.generateBill(list);

            Console.WriteLine("\n================================================");


            Item i1 = new Item { Id = 1, Rate = 1000 };
            Item i2 = new Item { Id = 2, Rate = 100 };
            Item i3 = new Item { Id = 3, Rate = 2000 };
            Item i4 = new Item { Id = 4, Rate = 200 };
            Item i5 = new Item { Id = 5, Rate = 3000 };
            Item i6 = new Item { Id = 6, Rate = 300 };
            Item i7 = new Item { Id = 7, Rate = 5000 };
            Item i8 = new Item { Id = 8, Rate = 500 };
            Item i9 = new Item { Id = 9, Rate = 900 };
            Item i10 = new Item { Id = 10, Rate = 800 };
            Item i11 = new Item { Id = 11, Rate = 1500 };





            List<Item> items = new List<Item>
            {
                i1, i2, i3, i4, i5, i6, i7, i8, i9,i10,i11
            };

            Console.WriteLine("\nItems With Rate Less Than 1000 : \n");
            FindItemsForUser(items);
            Console.ReadLine();
          



        }


        public static void FindItemsForUser(List<Item> items)
        {
            ICurrencyConverter currencyConverter = new CurrencyConverter();
            List<Item> list = items.Where(item => item.Rate < 1000).ToList();
            Console.WriteLine(" Item_No \t Rate_In_Rupees \t Rate_In_Dollars");
            foreach (Item item in list)
            {
                var RateInRupee = currencyConverter.ConvertUSDToINR(item.Rate);
                Console.WriteLine($" {item.Id}\t\t {item.Rate}\t\t\t {RateInRupee}");
            }
        }
    }
    
    public class BillingSys
    {
        StdTaxCalc taxCalc = new StdTaxCalc();
        public void generateBill(SaleList list)
        {
            double GrandTotal = 0;
            foreach(Sale item in list.Sales)
            {
               var item_total = ( item.SaleItem.Rate) * (item.qty);
                var itemTotal_afterDis = (item_total) - ((item.disc * item_total) / 100);
                GrandTotal += itemTotal_afterDis;
            }
           double GrandTotal_AfterTax = GrandTotal+  taxCalc.getIST("KARNATAKA", GrandTotal) + taxCalc.getFedTax(GrandTotal);
            Console.WriteLine("\nGrand Total = " + GrandTotal_AfterTax);

        }

        
    }

    public class StdTaxCalc
    {
        public double getIST(string state, double total)
        {
            int ist = 10;  // default as of now 
            ist = int.Parse(ConfigurationManager.AppSettings["IST"]);  // if any change
          
                return total * ist / 100;
        
        }
        public double getFedTax(double total)
        {
            int fed = 15;
            fed = int.Parse(ConfigurationManager.AppSettings["FED"]);
                
            return total * fed / 100;
           
        }
    }

    public class SaleItem
    {
        public double Rate;
        public string Des;
        public SaleItem() { }
        public SaleItem(string des, double rate)
        {
            this.Rate = rate;
            this.Des = des;
        }
        public string getDesc()
        {
            return Des;
        }
        public double getRate()
        {
            return Rate;
        }
    }
    public class Sale
    {
        public int qty;
        public double disc;
        public SaleItem SaleItem { get; set; }
        public Sale() { }
        public Sale(SaleItem _item, int _qty, double _disc)
        {
            this.SaleItem = _item;
            this.qty = _qty;
            this.disc = _disc;
        }
        public SaleItem getItem()
        {
            return SaleItem;
        }
        public double getDisc()
        {
            return disc;
        }
        public double getQty()
        {
            return qty;
        }

    }
    public class SaleList
    {
        public string dtSale;
        public string custName;

        public List<Sale> Sales { get; set; } = new List<Sale>();
        public SaleList() { }

        public SaleList(string dtSale, string custName)
        {
            this.dtSale = dtSale;
            this.custName = custName;
           
        }
    
        public string getCustName()
        {
            return custName;
        }
        public string getDtSale()
        {
            return dtSale;
        }
        public void add(Sale sale)
        {
            Sales.Add(sale);
        }
        public List<Sale> getSales()
        {
            return Sales;
        }

    }

    public class Item
    {
        public int Id { get; set; } 
        public double Rate {  get; set; }
    }
   

    public interface ICurrencyConverter
    {
        double ConvertUSDToINR(double rate);
    }
    public class CurrencyConverter : ICurrencyConverter
    {
        public double ConvertUSDToINR(double rate)
        {
            return rate * 82.9;
        }
    }

}
