﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static Sriram_M_Bharadwaj_Point_Of_Sale.CurrencyConverter;

namespace Sriram_M_Bharadwaj_Point_Of_Sale
{
    internal class Program
    {
        static void Main(string[] args)
        {
             SaleItem item1 = new SaleItem("Monitor",7000);
            SaleItem item2 = new SaleItem("Hard disk", 5500);
            Sale sale1 = new Sale(item1,2,5);
            Sale sale2 = new Sale(item2, 5, 10);
            SaleList list = new SaleList(DateTime.Parse("18/08/2005"),"Jennifer");
            list.Add(sale1);
            list.Add(sale2);
            BillingSystem sys = new BillingSystem();
            double grandTotal=sys.GenerateBill(list);
            Console.WriteLine("Grand Total : "+grandTotal);
            Console.WriteLine("----------------------------------------");
            //-----------------------------------------------------------------------------------------------------//
            //Q4
            SaleItem i1 = new SaleItem() { ItemId = 101, Description = "Phone", Rate = 1000 };
            SaleItem i2 = new SaleItem() { ItemId = 102, Description = "Television", Rate = 800 };
            SaleItem i3 = new SaleItem() { ItemId = 103, Description = "Groceries", Rate = 100 };
            List<SaleItem> items = new List<SaleItem>() { i1, i2, i3 };


            List<SaleItem> list2 = new Program().findItemsForUser(items);
            ICurrencyConverter currencyConverter = new UsdtoInr();
            Console.WriteLine("Q4");
            Console.WriteLine("Items under 1000");
            Console.WriteLine("Item-ID\tUSD\tINR");
            foreach (SaleItem item in list2)
            {
                Console.WriteLine(item.ItemId +"\t"+ item.Rate+"\t"+currencyConverter.Convert(item.Rate));
            }

        }
        //Q4
        public List<SaleItem> findItemsForUser(List<SaleItem> items)
        {
            List<SaleItem> list = new List<SaleItem>();
            foreach (SaleItem item in items)
            {
                if (item.Rate < 1000)
                {
                 list.Add(item);
                }
               
            }
            return list;
        }
        //An interface is created for currency conversion. Every class that implemnts this interface must implement the convert method.
       

     
    }
    public class CurrencyConverter
    {
        public interface ICurrencyConverter
        {
            double Convert(double amount);
        }
        public class UsdtoInr : ICurrencyConverter
        {
            public double Convert(double amount)
            {
                return amount * 84;
            }
        }
    }

    public class SaleItem
    {
        public int ItemId { get; set; } // Added for Q4
        public double Rate { get; set; }
        public string Description { get; set; }
        public SaleItem()
        {


        }
        public SaleItem(string desc, double rt)
        {
            Description = desc;
            Rate = rt;
        }

    }
    public class Sale
    {
        public int Qty { get; set; }
        public double Discount { get; set; }
        public SaleItem SaleItem { get; set; } // Each sale holds a SaleItem object
        public Sale()
        {

        }
        public Sale(SaleItem saleItem, int qty, double disc)
        {
            SaleItem = saleItem;
            Qty = qty;
            Discount = disc;
        }

    }

    public class SaleList
    {
        public DateTime DtSale { get; set; }
        public string CustName { get; set; }

        public List<Sale> Sales { get; set; } = new List<Sale>(); // SaleList has a list of sale objects 
        public SaleList()
        {
            
        }
        public SaleList(DateTime date, string name)
        {
            DtSale = date;
            CustName = name;
        }

        public void Add(Sale sale)
        {
            Sales.Add(sale);
        }
        
    }
    public class BillingSystem
    {
        StdTaxCalc tax = new StdTaxCalc();

        // Since State can vary , to avoid recompilation of code, "App.config" contains key value pair of state . Through GetState() method, current state is extracted.
        //Since IST and Fed Tax can also change, they are stored in "App.config" file and fetched from it.

        public double GenerateBill(SaleList saleList)
        {
            double grandTotal = 0;
            foreach (var item in saleList.Sales)
            {
                grandTotal += ((item.Qty * item.SaleItem.Rate) * (1 - (item.Discount / 100))) + (tax.GetIST(State.GetState()) + tax.GetFedTax());
                //iterates through all the sale objects in sale list and computes grand total by subtracting discount amount and adding IST and federal tax.
            }
            return grandTotal;
        }

    }

    public static class State
    {
        public static  string GetState()
        {
            
            return ConfigurationManager.AppSettings["State"];
        }
    }

    public  class StdTaxCalc
    {
        public  double GetIST(string state)
        {
            return double.Parse(ConfigurationManager.AppSettings[state]);
        }
        public  double GetFedTax()
        {
            return double.Parse(ConfigurationManager.AppSettings["fed"]);
        }

    }
}
