﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PointOfSale
{
    public class Program
    {
        static void Main(string[] args)
        {
            SaleItem item1= new SaleItem("Monitor",7000);
            SaleItem item2 = new SaleItem("Hard disk", 5500);
            Sale sale1 = new Sale("item1",2, 5);
            sale1.saleItem = item1;
            Sale sale2 = new Sale("item2", 5, 10);
            sale2.saleItem = item2;
            List<SaleList> list = new List<SaleList>("18-02-2005", "jennifer");
            list.Add(sale1);
            list.Add(sale2);

            BillingSys sys= new BillingSys();
            sys.generateBill(list);
        }
    }
    public class SaleItem
    {
        public double rate { get; set; }
        public string des { get; set; }
        public SaleItem()
        {

        }
        public SaleItem(string des, double rt)
        {
            this.rate = rt;
            this.des = des;

        }
        public string getDesc()
        {
            return des;

        }
        public double getRate()
        {
            return rate;
        }
    }
    public class Sale
    {
        public int _qty { get; set; }
        public double _disc { get; set; }
        public SaleItem saleItem = new SaleItem();
        public Sale()
        {

        }
        public Sale(string item, int qty, int disc)
        {
            saleItem.des = item;
            _qty = qty;
            _disc = disc;

        }
        public SaleItem GetItem()
        {
            return saleItem;

        }
        public double getDisc()
        {
            return _disc;

        }
        public int getQty()
        {
            return _qty;
        }
    }
    public class SaleList
    {
        public string dtSale {  get; set; }
        public string custName { get; set; }
        private ArrayList sales = new ArrayList();
        public SaleList()
        {

        }
        public SaleList(string dtSale, string custName)
        {
            this.dtSale = dtSale;
            this.custName = custName;
            


        }
        public string getCustName()
        {
            return custName;

        }
        public string getDtSale()
        {
            return dtSale;
        }
        public void Add(Sale sale)
        {
            SaleList list = new SaleList();
            list.sales.Add(sale);

        }
        public ArrayList getSales()
        {
            return sales;

        }

        
    }

    internal class ArrayList<T>
    {
        internal void Add(Sale sale)
        {
            throw new NotImplementedException();
        }
    }

    public class BillingSys
    {
        StdTaxCalc taxCalc = new StdTaxCalc();
        public void generateBill(SaleList saleList)
        {
            
            Console.WriteLine("Enter the state:");
            string state = Console.ReadLine();
            double total = 0;
            foreach(Sale sale in saleList.getSales())
            {
                total = sale.saleItem.rate * sale._qty;
                total -= sale._disc;
                total += taxCalc.getIST(state) + taxCalc.FedTax();

            }
            Console.WriteLine($"The total bill for customer {saleList.custName} is: " + total);

        }
                
    }
            

}


    public class StdTaxCalc
    {
        public double getIST(String state)
        {

            return 0.1;


        }
        public double FedTax()
        {
            return 0.15;

        }
    }
