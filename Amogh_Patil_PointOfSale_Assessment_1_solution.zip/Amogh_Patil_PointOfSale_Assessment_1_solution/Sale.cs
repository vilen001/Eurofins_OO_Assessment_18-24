﻿namespace Point_Of_Sale_Assessment_1
{
    public class Sale
    { 
        public int Qty { get; set; }
        public double Disc {  get; set; }
        public SaleItem saleitem = new SaleItem();

        public Sale()
        {

        }
        public Sale(int qty, double disc, SaleItem si)
        {
            Qty = qty;
            Disc = disc;
            this.saleitem = si;
        }
        public SaleItem GetItem()
        {
            return saleitem;
        }
        public double GetDisc()
        {
            return Disc;
        }
        public int GetQty()
        {
            return Qty;
        }
    }

}
