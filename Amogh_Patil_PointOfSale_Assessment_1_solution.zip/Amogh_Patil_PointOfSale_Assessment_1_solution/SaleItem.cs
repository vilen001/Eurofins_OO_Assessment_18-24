﻿namespace Point_Of_Sale_Assessment_1
{
    public class SaleItem
    {
        public double Rate { get; set; }
        public string Des { get; set; }
        public SaleItem()
        {

        }
        public SaleItem(string des,double rate)
        {
            this.Des = des;
            this.Rate = rate;
        }
        public string GetDesc()
        {
            return Des;
        }
        public double GetRate()
        {
            return Rate;
        }
    }

}
