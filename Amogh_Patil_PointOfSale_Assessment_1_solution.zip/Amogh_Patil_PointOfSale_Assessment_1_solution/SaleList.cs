﻿using System;
using System.Collections.Generic;

namespace Point_Of_Sale_Assessment_1
{
    public class SaleList
    {
        public List<Sale> Sales = new List<Sale>();
        public string CustomerName { get; set; }
        public DateTime DtSale { get; set; }
        public SaleList()
        {

        }
        public SaleList(DateTime dt,string custname)
        {
            this.DtSale = dt;
            this.CustomerName = custname;
        }
        public string GetCustomerName()
        {
            return CustomerName;
        }
        public DateTime GetDtSale()
        {
            return DtSale;
        }
        public void Add(Sale s)
        {
            Sales.Add(s);
        }

        public List<Sale> GetSales()
        {
            return Sales;
        }
    }

}
