﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Point_Of_Sale_Assessment_1
{
    public partial class Program
    {
        static void Main(string[] args)
        {

            SaleItem item1 = new SaleItem("Monitor", 7000);
            SaleItem item2 = new SaleItem("Hard Disk", 5500);
            // qty , disc , item
            Sale sale1 = new Sale(2,5,item1); 
            Sale sale2 = new Sale(5,10,item2);
            

            DateTime d = new DateTime();

            // assign the date the given date value ... 
            DateTime.TryParse("2005-02-18", out d);
            SaleList list = new SaleList(d,"Jennifer");
            list.Add(sale1);
            list.Add(sale2);
            BillingSystem sys = new BillingSystem();
            sys.GenerateBill(list);


            ItemsRepository itsr = new ItemsRepository();
            List<SaleItem> saleItems = itsr.Get_Items();
            sys.FindItemsForUser(saleItems);
            Console.WriteLine();


        }


    }

}
