﻿namespace Point_Of_Sale_Assessment_1
{
    public class USD_To_INR : CurrencyConverter
    {
        public double Convert(double money)
        {
            return money * 85;
        }
    }

}
