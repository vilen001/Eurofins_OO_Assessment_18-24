﻿using System.Configuration;

namespace Point_Of_Sale_Assessment_1
{
    public class StdTaxCalc
    {
        public double GetIstTax(string state)
        {
            return double.Parse(ConfigurationManager.AppSettings[state]);
        }
        public double GetFedTax()
        {
            return double.Parse(ConfigurationManager.AppSettings["FT"]) ;
        }
    }

}
