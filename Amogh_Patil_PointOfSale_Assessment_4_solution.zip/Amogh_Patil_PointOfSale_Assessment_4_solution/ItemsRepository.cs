﻿using System.Collections.Generic;

namespace Point_Of_Sale_Assessment_1
{
    public partial class Program
    {
        public class ItemsRepository
        {

            SaleItem item3 = new SaleItem("IPhone", 10000);
            SaleItem item4 = new SaleItem("Earphone", 11);
            SaleItem item5 = new SaleItem("Watch", 5);
            SaleItem item6 = new SaleItem("Mouse", 9);

            public List<SaleItem>  Get_Items()
            {
                List<SaleItem> l = new List<SaleItem>
                {
                    item3,
                    item4,
                    item5,
                    item6
                };
                return l;

            }
        }


    }

}
