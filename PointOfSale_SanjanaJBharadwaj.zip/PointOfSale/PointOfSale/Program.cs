﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace PointOfSale
{
    internal class Program
    {   
        static void Main(string[] args)
        {
            SaleItem item1 = new SaleItem(7000, "Monitor");
            SaleItem item2 = new SaleItem(5000, "Hard Disk");

            Sale sale1 = new Sale(item1, 2, 5);
            Sale sale2 = new Sale(item2, 5, 10);
            SaleList list = new SaleList("18-08-2005", "Jennifer");
            list.Add(sale1);
            list.Add(sale2);
           
            BillingSys bill = new BillingSys();
            bill.GenerateBill(list);

            List<Item> items = part4.ReadItemsFromFile("itemList.txt");
            part4.FindItemsForUser(items);

        }
    }

    //class sale item contains rate and description
    public class SaleItem
    {
        double rt;
        private double Rate 
        {
            set { rt = value; }
            get { return rt; }
        }
        private string Des { get; set; }

        public SaleItem() { }
        public SaleItem(double rate, string des) 
        {
            Rate = rate;
            Des = des;
        }

        public string GetDesc()
        {
            return Des;
        }

        public double GetRate()
        {
            return Rate;
        }      
    }

    //class Sale contains quantity and discount 
    public class Sale
    {
        int qty;
        double disc;
        //Sale has SaleItem
        SaleItem _item = new SaleItem();
        private int _qty

        {
            set { qty = value; }
            get { return qty; }
        }

        private double _disc
        {
            set { disc = value; }
            get { return disc; }
        }

       
        public Sale() { }
        public Sale(SaleItem item, int qty, double disc) 
        {
            _item  = item;
            _qty = qty;
            _disc = disc;
        }

        public SaleItem getItem() { return  _item; }    
        public double GetDisc() { return _disc; }
        public int GetQty() { return _qty; }
    }


    public class SaleList
    {

        private ArrayList sales = new ArrayList();
        private string dtSal { get; set; }
        private string custName { get; set; }
        public SaleList() { }
        public SaleList(string dtSal, string custName)
        {
            this.dtSal = dtSal;
            this.custName = custName;
        }
        public string getCustName()
        {
            return custName;
        }
        public string GetDtSal() { return dtSal; }
        public void Add(Sale sale)
        {
            sales.Add(sale);
        }
        public ArrayList GetSales()
        {
            return sales;
        }
    }

    public class BillingSys
    {
        private StdTaxCalc taxCalculator;
        public void GenerateBill(SaleList list)
        {
            double subTotal = 0, grandTotal =0;
            StdTaxCalc taxCalculator = StdTaxCalc.Create(0.10, 0.15);
            Console.WriteLine("Rate\tQuantity\tSub-Total");
            foreach (Sale sale in list.GetSales())
            {
                SaleItem item = sale.getItem();
                double rate = item.GetRate(); 
                int quantity = sale.GetQty();
                double discount = sale.GetDisc();
                subTotal = rate* quantity  - discount;
                
                

                Console.WriteLine($"{rate}\t {quantity}\t \t{subTotal}");
            }
            double ist = taxCalculator.GetIST("Karnataka");
            double fedTax = taxCalculator.GetFedTax();
            double totalTax = subTotal * (ist + fedTax);
            grandTotal += subTotal + totalTax;
            Console.WriteLine($"The Grand total is {grandTotal}");

        }
    }

    public class StdTaxCalc
    {
        private double ISTRate;
        private double FEDRate;

        private StdTaxCalc(double IstRate, double FedRate)
        {
            ISTRate = IstRate;
            FEDRate = FedRate;
        }

        public static StdTaxCalc Create(double IstRate, double FedRate)
        {
            return new StdTaxCalc(IstRate,  FedRate);
        }

        public double GetIST(string state)
        {
            if (state == null)
                return 0;
            return ISTRate;
        }

        public double GetFedTax()
        {
            return FEDRate;
        }
    }

    public interface ICurrencyConverter
    {
        double USDToINR(double Amount);
    }
    public class CurrencyConverter : ICurrencyConverter
    {
      
        public double USDToINR(double amt)
        {
            return amt * 82.91;
        }
    }
    public class Item
    {
        public int ItemNo { get; set; }
        public string Name { get; set; }
        public double Rate { get; set; }


        public Item() { }
        public Item(int itemNo,string name, double rate)
        {
            ItemNo = itemNo;
            Name = name;
            Rate = rate;
        }
    }
    
    public class part4
    {
        public static List<Item> ReadItemsFromFile(string filePath)
        {
            List<Item> items = new List<Item>();

            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] parts = line.Split(',');
                        int itemNo = int.Parse(parts[0]);
                        string name = parts[1];
                        double rate = double.Parse(parts[2]);
                        items.Add(new Item(itemNo,name, rate));
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading file: {ex.Message}");
            }

            return items;
        }
        public static void FindItemsForUser(List<Item> items)
        {
            CurrencyConverter con = new CurrencyConverter();
            Console.WriteLine("Items you might like - ");
            foreach (var item in items)
            {
                if (item.Rate < 1000)
                {
                    double rateINR = con.USDToINR(item.Rate);
                    Console.WriteLine($"Item No: {item.ItemNo}, Name : {item.Name}, Rate: {rateINR} INR");
                }
            }
        }
    }

}
