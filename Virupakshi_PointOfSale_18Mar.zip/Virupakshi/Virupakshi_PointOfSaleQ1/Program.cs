﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Virupakshi_PointOfSaleQ1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SaleItem item1 = new SaleItem("Monitor", 7000);
            SaleItem item2 = new SaleItem("Hard disk", 5500);

            List<SaleItem> items = new List<SaleItem>();
            items.Add(item1);
            items.Add(item2);

            Sale sale1 = new Sale(item1, 2, 5);
            Sale sale2 = new Sale(item2, 5, 10);

            SaleList list1 = new SaleList("18-08-2005", "Jennifer");
            list1.add(sale1);
            list1.add(sale2);

            BillingSys billingSys = new BillingSys();
            billingSys.GenerateBill(list1);

            FindItemsForUser(items);
        }

        public static void FindItemsForUser(List<SaleItem> list)
        {
            //Console.WriteLine("Hi");
            int count = 1;
            foreach (var item in list)
            {
                if (item.Rate <= 1000)
                {
                    CurrencyConverterFactory factory = CurrencyConverterFactory.Instance;
                    ICurrencyConverter currencyConverter = factory.CreateTaxCalculator();
                    Console.WriteLine($"ItemNo {count} : Rate in INR = {currencyConverter.UsdToInr(item.Rate)}");
                }
                count++;
            }
        }
    }

    public class Sale
    {
        public int Qty { get; set; }
        public double Dis { get; set; }
        public SaleItem Item { get; set; } = new SaleItem();
        public Sale()
        {

        }
        public Sale(SaleItem item, int qty, double disc)
        {
            Item = item;
            Qty = qty;
            Dis = disc;
        }
    }

    public class SaleItem
    {

        public string Desc { get; set; }
        public double Rate { get; set; }

        public SaleItem()
        {

        }
        public SaleItem(string des, double rt)
        {
            this.Desc = des;
            this.Rate = rt;
        }


    }

    public class SaleList
    {
        public DateTime DtSale { get; set; }
        public string CustName { get; set; }
        public List<Sale> Sales { get; set; } = new List<Sale>();
        public SaleList(string v1, string v2)
        {
            DtSale = DateTime.Parse(v1);
            CustName = v2;
        }

        public void add(Sale sale)
        {
            Sales.Add(sale);
        }
    }

    public class BillingSys
    {
        public void GenerateBill(SaleList list)
        {
            double res = 0;
            foreach (var sale in list.Sales)
            {
                res += sale.Qty * sale.Item.Rate - (sale.Dis * (sale.Qty * sale.Item.Rate) / 100);
                //Console.WriteLine(res);
            }
            Console.WriteLine($"Total : {res}");
            Console.WriteLine($"Total with state tax = {res + (res * StdTaxCalc.GetIST("Ka") / 100)}");
            Console.WriteLine($"Total with Federal Tax = {res + (res * StdTaxCalc.FedTax() / 100)}");
        }
    }

    public class StdTaxCalc
    {
        public static double GetIST(string state)
        {
            XDocument xml = XDocument.Load(@"C:\Users\K VIRUPAKSHI\source\repos\Virupakshi\Virupakshi_PointOfSaleQ1\XMLFile1.xml");
            var tax = from t in xml.Descendants("Tax")
                      select t.Element("IST").Value;
            foreach (var t in tax)
                return double.Parse(t);
            return 0;
            //return 10;
        }
        public static double FedTax()
        {
            XDocument xml = XDocument.Load(@"C:\Users\K VIRUPAKSHI\source\repos\Virupakshi\Virupakshi_PointOfSaleQ1\XMLFile1.xml");
            var tax = from t in xml.Descendants("Tax")
                      select t.Element("FederalTax").Value;
            foreach (var t in tax)
                return double.Parse(t);
            return 0;
            //return 15;
        }
    }


    public interface ICurrencyConverter
    {
        double UsdToInr(double amt);
    }

    public class CurrencyConverter : ICurrencyConverter
    {
        public double UsdToInr(double amt)
        {
            return amt * 83;
        }
    }

    class CurrencyConverterFactory // OCP - Singleton
    {
        //1. don't allow the clients to create an instance - private constructor

        protected CurrencyConverterFactory()
        {

        }

        //2. internalize the object creation - self object creation

        public static readonly CurrencyConverterFactory Instance = new CurrencyConverterFactory();

        public virtual ICurrencyConverter CreateTaxCalculator()
        {
            // Use the configuration files (text files)
            string className = ConfigurationManager.AppSettings["CALC"];

            // Reflextion - Self diagnostics
            Type theType = Type.GetType(className);
            return (ICurrencyConverter)Activator.CreateInstance(theType);
        }

    }
}
